/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package electricitybillingsys;
import java.sql.*;

/**
 *
 * @author Lenovo
 */
public class Conn {
    
    Connection c;
    Statement s;
    
    public Conn(){ //non parametrized constructor
        try{
            Class.forName("com.mysql.cj.jdbc.Driver"); //its is a method to used for istablished connection to jdbc driver
            c =DriverManager.getConnection("jdbc:mysql:///ebs","root","root123");    
            s =c.createStatement(); 
        }catch(Exception e){
            System.out.println(e);
        }
    }
     
}
